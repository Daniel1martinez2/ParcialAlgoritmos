package view;

import controller.Controller;
import processing.core.PApplet;


public class Main extends PApplet {
	Controller controller; 
	boolean n; 
	boolean p; 
	boolean o; 
	boolean i; 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		PApplet.main(Main.class.getName());

	}
	public void settings() {
		size(600,600); 

	}

	public void setup() {
		controller = new Controller(this); 
		controller.cargoTexto();
		n = false;
		p = false; 
		o = false; 
		i = false; 

	}

	public void draw() {
		background(0); 
		for (int i = 0; i < controller.getCont().size(); i++) {
			controller.getCont().get(i).pintar(80+i*40); 
		}
		if(n) {
			fill(0,255,0); 
		}else {fill(255,255,255); }
		text("key N = order by rating", 20,30);
		if(p) {
			fill(0,255,0); 
		}else {fill(255,255,255); }
		text("key P = order by name", 20,60);
		if(o) {
			fill(0,255,0); 
		}else {fill(255,255,255); }
		text("key O = order by year", 20,90);
		if(i) {
			fill(0,255,0); 
		}else {fill(255,255,255); } 
		text("key I = order by type", 20,120);
		

	}
	
	public void keyPressed() {
		controller.sortList(key);
		switch (key) {
		case 'n':
				n= true; 
				p=false; 
				o= false; 
				i=false; 
			break;
		case 'p':
			p= true; 
			n=false; 
			o= false; 
			i=false; 
			
		break;

		case 'o':
			o= true; 
			n=false; 
			p=false; 
			i=false; 
		break;
		case 'i':
			n=false; 
			p=false;
			o=false; 
			i= true; 
		break;


		default:
			break;
		}
	}

}
