package model;

import processing.core.PApplet;

public abstract class Contenido implements Comparable<Contenido>{
	
	protected int posx,posy,year,rating;
	protected String name,type, img; 
	protected PApplet app; 

	public Contenido(String name,int rating, int year,String type, String img, PApplet app   ) {
		
		this.app= app; 
		this.img =img; 
		this.name= name; 
		this.posx = app.width/2 ; 
		this.rating = rating; 
		this.type= type; 
		this.year = year; 
		
		
		
	}
	
	public abstract void pintar(int posy); 

	public int getPosx() {
		
		return posx;
	}

	public void setPosx(int posx) {
		this.posx = posx;
	}

	public int getPosy() {
		return posy;
	}

	public void setPosy(int posy) {
		this.posy = posy;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getRating() {
		return rating;
	}

	public void setRating(int rating) {
		this.rating = rating;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getImg() {
		return img;
	}

	public void setImg(String img) {
		this.img = img;
	}

}
