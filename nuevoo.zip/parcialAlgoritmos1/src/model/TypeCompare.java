package model;

import java.util.Comparator;

public class TypeCompare implements Comparator<Contenido> {

	public TypeCompare() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int compare(Contenido o1, Contenido o2) {
		// TODO Auto-generated method stub
		return o1.getType().compareTo(o2.getType());
	}

}
