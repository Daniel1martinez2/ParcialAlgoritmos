package model;

import java.util.Collections;
import java.util.LinkedList;

import processing.core.PApplet;

public class Logic {
	private String []loadtext1 ; 
	private LinkedList<Contenido>cont; 
	private NameCompare companame; 
	private YearCompare compayear; 
	private TypeCompare compatype; 

	//----
	 Contenido index1;
	 int click; 
	 int guardar[]; 
	
	 //--
	String separo[]; 
	PApplet app; 

	public Logic(PApplet app) {
		this.app= app; 
		cont = new LinkedList<Contenido>(); 
		companame= new NameCompare(); 
		compayear = new YearCompare(); 
		compatype = new TypeCompare(); 
	 
		
	}
	
	public void cargotexto() {
		loadtext1 = app.loadStrings("../data/netflix.txt");
		
		for (int i = 0; i < loadtext1.length; i++) {
			 separo= loadtext1[i].split(","); 
			
			String name = separo[0]; 
			int rating = Integer.parseInt(separo[2]); 
			int year = Integer.parseInt(separo[1]); 
			String type = separo[3]; 
			String img = separo[0].toLowerCase(); 
			
			if(type.equals("serie")) {
				cont.add(new Serie(name,rating, year, type, img, app)); 
				//System.out.println(cont.get(i).getName());
			}else {
				cont.add(new Movie(name,rating, year, type, img, app)); 
			}
			
			
			
		 
			
		
		}
		
	
	}
	
	//-----------------------
	public void sortList(char c) {
		switch (c) {
		case 'n':
			System.out.println("orderno natural");
			Collections.sort(cont);
			String ordenadoRating[] = new String[loadtext1.length];
			for (int i = 0; i < ordenadoRating.length; i++) { 
				ordenadoRating[i]=String.valueOf(cont.get(i).getRating()); 
			}
			app.saveStrings("../parcialAlgoritmos1/data/porRating.txt", ordenadoRating);
			
			
			break; 
		case 'p':
			System.out.println("orderno nombre");
			Collections.sort(cont,companame);
			
			String ordenadoName[] = new String[loadtext1.length];
			for (int i = 0; i < ordenadoName.length; i++) { 
				ordenadoName[i]=String.valueOf(cont.get(i).getName()); 
			}
			app.saveStrings("../parcialAlgoritmos1/data/pornombre.txt", ordenadoName);
			
			
			break;
		case 'o':
			System.out.println("orderno year");
			Collections.sort(cont,compayear);
			
			String ordenadoYear[] = new String[loadtext1.length];
			for (int i = 0; i < ordenadoYear.length; i++) { 
				ordenadoYear[i]=String.valueOf(cont.get(i).getYear()); 
			}
			app.saveStrings("../parcialAlgoritmos1/data/porAño.txt", ordenadoYear);
			
			break;
		case 'i':
			System.out.println("orderno type");
			Collections.sort(cont,compatype);
			
			String ordenadoType[] = new String[loadtext1.length];
			for (int i = 0; i < ordenadoType.length; i++) { 
				ordenadoType[i]=String.valueOf(cont.get(i).getType()); 
			}
			app.saveStrings("../parcialAlgoritmos1/data/portipo.txt", ordenadoType);
			
			break;
		default:
			System.out.println("Invalid key");
			break;
		}
	}
	//-----------------------


	public LinkedList<Contenido> getCont() {
		return cont;
	}

	public void setCont(LinkedList<Contenido> cont) {
		this.cont = cont;
	}
	
	

}
