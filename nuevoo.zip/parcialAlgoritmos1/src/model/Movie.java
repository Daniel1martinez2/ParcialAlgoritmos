package model;

import processing.core.PApplet;


public class Movie extends Contenido {
PApplet app; 
	public Movie(String name,int rating, int year,String type, String img, PApplet app ) {
		super(name, rating,year, type, img, app); 
		this.app= app; 

	}

	public void pintar(int posy) {
		
		app.ellipse(app.width/2 -60,posy,30,30); 
		app.text(getName()+" "+getRating()+" "+getType()+" "+getYear(),app.width/2-60 +60 , posy);
		
	}

	@Override
	public int compareTo(Contenido o) {
		// TODO Auto-generated method stub
		return this.rating - o.getRating();
	}

}
