package controller;

import java.util.LinkedList;

import model.Contenido;
import model.Logic;
import processing.core.PApplet;

public class Controller {
	
	Logic logic; 
	PApplet app; 

	public Controller(PApplet app) {
		this.app= app; 
		logic = new Logic(app); 
	}
	
	
	public void cargoTexto() {
		logic.cargotexto();
	}
	public LinkedList<Contenido> getCont() {
		return logic.getCont();
	}
	
	public void sortList(char c) {
		logic.sortList(c);
	}
	


}
