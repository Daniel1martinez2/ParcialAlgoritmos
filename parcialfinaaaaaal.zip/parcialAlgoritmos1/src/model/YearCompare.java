package model;

import java.util.Comparator;

public class YearCompare implements  Comparator<Contenido> {

	public YearCompare() {
		// TODO Auto-generated constructor stub
	}

	@Override
	public int compare(Contenido o1, Contenido o2) {
		// TODO Auto-generated method stub
		return o1.getYear()-o2.getYear();
	}

}
