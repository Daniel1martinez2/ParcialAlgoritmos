package model;

import processing.core.PApplet;
import processing.core.PImage;


public class Movie extends Contenido {
PApplet app; 
	public Movie(String name,int rating, int year,String type, PImage imagen, PApplet app ) {
		super(name, rating,year, type, imagen, app); 
		this.app= app; 

	}

	public void pintar(int posy) {
		
		app.image(img,app.width/2-60,posy-14,30,30); 
		app.text(getName()+" "+getRating()+" "+getType()+" "+getYear(),app.width/2-60 +60 , posy);
		
	}

	@Override
	public int compareTo(Contenido o) {
		// TODO Auto-generated method stub
		return this.rating - o.getRating();
	}

}
