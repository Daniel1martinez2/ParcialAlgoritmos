package model;

import java.util.Comparator;

public class NameCompare implements Comparator<Contenido>{

	public NameCompare() {
		// TODO Auto-generated constructor stub
	}

	public int compare(Contenido o1, Contenido o2) {
		// TODO Auto-generated method stub
		return o1.getName().compareTo(o2.getName());
	}

}
